<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - CSD</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    

    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet">

    <link href="build/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="build/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="build/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="build/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="build/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

    <link href="build/assets/css/main.css" rel="stylesheet">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

  </head>

  <body class="index-page">
    <?php if(Auth::user()): ?>
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('welcome');

$__html = app('livewire')->mount($__name, $__params, 'lw-74784495-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard');

$__html = app('livewire')->mount($__name, $__params, 'lw-74784495-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php else: ?>
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('welcome');

$__html = app('livewire')->mount($__name, $__params, 'lw-74784495-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer');

$__html = app('livewire')->mount($__name, $__params, 'lw-74784495-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <a class="scroll-top d-flex align-items-center justify-content-center" id="scroll-top" href="#"><i
        class="bi bi-arrow-up-short"></i></a>

    <div id="preloader"></div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <script src="<?php echo e(asset('build/assets/vendor/sweetalert2/dist/sweetalert2.all.min.js')); ?>"></script>
    <?php if (isset($component)) { $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-alert::components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $attributes = $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $component = $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
    <script src="build/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="build/assets/vendor/php-email-form/validate.js"></script>
    <script src="build/assets/vendor/aos/aos.js"></script>
    <script src="build/assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="build/assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="build/assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="build/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="build/assets/vendor/purecounter/purecounter_vanilla.js"></script>

    <script src="build/assets/js/main.js"></script>

  </body>

</html>
<?php /**PATH /var/www/html/CSD/resources/views/welcome.blade.php ENDPATH**/ ?>